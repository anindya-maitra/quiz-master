<template>
  <div>
    <div class="container mt-3">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
/* Global Styles */
body {
  font-family: Arial, sans-serif;
  background-color: #f8f9fa;
}
</style>
