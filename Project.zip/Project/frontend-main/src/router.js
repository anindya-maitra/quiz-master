import { createRouter, createWebHistory } from "vue-router";
import LandingPage from "@/components/LandingPage.vue";
import UserLogin from "@/components/UserLogin.vue";
import UserSignup from "@/components/UserSignup.vue";
import UserDashboard from "@/components/UserDashboard.vue";
import QuizPage from "@/components/QuizPage.vue";
import UserScores from "@/components/UserScores.vue";  
import UserSummary from "@/components/UserSummary.vue";

import AdminDashboard from "@/components/AdminDashboard.vue";
import NewSubject from "@/components/NewSubject.vue";
import SubjectList from "@/components/SubjectList.vue";
import NewChapter from '@/components/NewChapter.vue';
import ChapterList from '@/components/ChapterList.vue';
import AdminQuizMgmt from "@/components/AdminQuizMgmt.vue";
import NewQuiz from "@/components/NewQuiz.vue";
import NewQuestion from "@/components/NewQuestion.vue";
import AdminCharts from '@/components/AdminCharts.vue';




const routes = [
  { path: "/", component: LandingPage },
  { path: "/login", component: UserLogin },
  { path: "/signup", component: UserSignup },
  // { path: "/userdashboard", component: UserDashboard },
  { path: "/user/dashboard/:userId", component: UserDashboard, props: true },
  { path: "/user/scores/:userId", component: UserScores, props: true },
  { path: "/quiz/:quizId", component: QuizPage, props: true },
  { path: "/user/summary/:userId", component: UserSummary, props: true },

  { path: "/admin/dashboard", component: AdminDashboard },
  { path: "/admin/subjects", component: SubjectList },
  { path: "/admin/new-subject", component: NewSubject },
  { path: "/admin/chapters", component: ChapterList },
  { path: "/admin/new-chapter", component: NewChapter },
  { path: "/admin/quizzes", component: AdminQuizMgmt },
  { path: "/admin/new-quiz", component: NewQuiz },
  { path: "/admin/new-question/:quizId", component: NewQuestion, props: true },
  { path: '/admin/summary', component: AdminCharts },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
