<template>
    <div class="container mt-4">
      <h2>Manage Subjects</h2>
      <ul class="list-group">
        <li v-for="subject in subjects" :key="subject.id" class="list-group-item">
          {{ subject.name }} - {{ subject.desc }}
        </li>
      </ul>
      <form @submit.prevent="createSubject" class="mt-3">
        <div class="form-group">
          <input type="text" v-model="newSubject.name" class="form-control" placeholder="Subject Name" required>
        </div>
        <div class="form-group">
          <input type="text" v-model="newSubject.desc" class="form-control" placeholder="Description" required>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Add Subject</button>
      </form>
    </div>
  </template>
  
  <script>
export default {
  name: "SubjectList",
  data() {
    return {
      subjects: [],
      newSubject: { name: "", desc: "" },
    };
  },
  mounted() {
    fetch("http://localhost:5000/admin/subjects")
      .then((response) => response.json())
      .then((data) => (this.subjects = data));
  },
  methods: {
    createSubject() {
      fetch("http://localhost:5000/admin/subjects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(this.newSubject),
      }).then(() => {
        this.subjects.push({ ...this.newSubject });
        this.newSubject = { name: "", desc: "" };
      });
    },
  },
};
</script>

  