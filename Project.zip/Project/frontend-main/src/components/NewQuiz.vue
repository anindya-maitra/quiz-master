<template>
    <div class="container mt-4">
      <h2 class="mt-3">Add New Quiz</h2>
      <form @submit.prevent="createQuiz" class="mt-3 me-2">
        <!-- Subject Selection -->
        <div class="form-group">
          <label>Subject:</label>
          <select v-model="selectedSubject" class="form-control" @change="fetchChapters">
            <option v-for="subject in subjects" :key="subject.id" :value="subject.id">
              {{ subject.name }}
            </option>
          </select>
        </div>
  
        <!-- Chapter Selection (only shows if a subject is selected) -->
        <div class="form-group" v-if="selectedSubject">
          <label>Chapter:</label>
          <select v-model="quiz.chapter_id" class="form-control">
            <option v-for="chapter in chapters" :key="chapter.id" :value="chapter.id">
              {{ chapter.name }}
            </option>
          </select>
        </div>
  
        <!-- Other Fields -->
        <div class="form-group">
          <label>Date:</label>
          <input type="date" v-model="quiz.date_of_quiz" class="form-control" required>
        </div>
        <div class="form-group">
          <label>Total Score:</label>
          <input type="number" v-model="quiz.total_score" class="form-control" required>
        </div>
        <div class="form-group">
          <label>Duration (hh:mm:ss):</label>
          <input type="text" v-model="quiz.time_duration" class="form-control" required>
        </div>
        <div class="form-group">
          <label>Difficulty Level:</label>
          <select v-model="quiz.difficulty_level" class="form-control" required>
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>
        </div>
  
        <button type="submit" class="btn btn-primary mt-3">Create Quiz</button>
        <router-link to="/admin/quizzes" class="btn btn-secondary mt-3 ms-2">Close</router-link>
      </form>
  
      <!-- Modal for No Chapters Available -->
      <div v-if="showModal" class="modal" tabindex="-1" style="display: block; background-color: rgba(0, 0, 0, 0.5);">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">No Chapters Available</h5>
              <button type="button" class="btn-close" @click="closeModal"></button>
            </div>
            <div class="modal-body">
              <p>This subject has no chapters available. Would you like to create a new chapter or go back to the Dashboard?</p>
            </div>
            <div class="modal-footer">
              <router-link to="/admin/new-chapter" class="btn btn-success">Create New Chapter</router-link>
              <router-link to="/admin/dashboard" class="btn btn-secondary">Go to Dashboard</router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import axios from "axios";
  
  export default {
    data() {
      return {
        quiz: {
          chapter_id: "",
          date_of_quiz: "",
          total_score: "",
          time_duration: "",
          difficulty_level: "Easy"
        },
        subjects: [],
        selectedSubject: "",
        chapters: [],
        showModal: false // To control modal visibility
      };
    },
    methods: {
      async fetchSubjects() {
        try {
          const response = await axios.get("http://localhost:5000/admin/subjects");
          this.subjects = response.data;
        } catch (error) {
          console.error("Error fetching subjects:", error);
        }
      },
      async fetchChapters() {
        if (!this.selectedSubject) {
          this.chapters = []; // Clear chapters if no subject selected
          return;
        }
        try {
          const response = await axios.get(`http://localhost:5000/admin/chapters?subject_id=${this.selectedSubject}`);
          this.chapters = response.data;
  
          // Check if there are no chapters and show the modal
          if (this.chapters.length === 0) {
            this.showModal = true;
          }
        } catch (error) {
          console.error("Error fetching chapters:", error);
        }
      },
      async createQuiz() {
        if (!this.quiz.chapter_id) {
          alert("Please select a chapter!");
          return;
        }
  
        try {
          await axios.post("http://localhost:5000/admin/quizzes", this.quiz);
          alert("Quiz added successfully!");
          this.$router.push("/admin/quizzes");
        } catch (error) {
          alert("Error adding quiz: " + error.response.data.error);
        }
      },
      closeModal() {
        this.showModal = false; // Close the modal
      },
      createChapter() {
        this.$router.push(`/admin/chapters/create?subject_id=${this.selectedSubject}`); // Navigate to chapter creation page
      }
    },
    mounted() {
      this.fetchSubjects(); // Fetch subjects on page load
    }
  };
  </script>
  
  <style scoped>
  .modal {
    display: block;
  }
  .modal-dialog {
    max-width: 400px;
    margin: 20% auto;
  }
  .navbar {
    background-color: #b2d5f8 !important;
    border-bottom: 2px solid #ccc;
    }
    .navbar-nav .nav-link {
    color: black;
    font-weight: 500;
    }
    </style>
  