<template>
  <div class="quiz-container">
    <nav class="navbar navbar-dark bg-primary p-2">
      <span class="navbar-brand mx-auto">Quiz Master</span>
    </nav>

    <div class="container mt-4">
      <div class="d-flex justify-content-between align-items-center">
        <h4>Q. No. {{ currentIndex + 1 }} / {{ questions.length }}</h4>
        <div class="timer-box">{{ formattedTime }}</div>
      </div>

      <div class="card p-4 mt-3">
        <h5 class="mb-4">{{ currentQuestion.quesStatement }}</h5>

        <div class="options">
          <div v-for="(option, index) in options" :key="index" class="form-check">
            <input
              class="form-check-input"
              type="radio"
              :id="'option' + index"
              :value="index + 1"
              v-model="selectedOption"
            />
            <label class="form-check-label" :for="'option' + index">{{ option }}</label>
          </div>
        </div>
      </div>

      <div class="d-flex justify-content-between mt-4">
        <button 
          class="btn btn-secondary" 
          @click="saveAnswerAndNext" 
          v-if="currentIndex < questions.length - 1"
        >
          Save and Next
        </button>
        <button class="btn btn-success" @click="submitQuiz">Submit</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      quizId: this.$route.params.quizId,
      userId: localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")).id : null,
      questions: [],
      currentIndex: 0,
      selectedOption: null,
      answers: [],
      timeDuration: 0,
      timer: null,
    };
  },
  computed: {
    currentQuestion() {
      return this.questions[this.currentIndex] || {};
    },
    options() {
      return [this.currentQuestion.option1, this.currentQuestion.option2].filter(Boolean);
    },
    formattedTime() {
      const minutes = String(Math.floor(this.timeDuration / 60)).padStart(2, "0");
      const seconds = String(this.timeDuration % 60).padStart(2, "0");
      return `${minutes}:${seconds}`;
    },
  },
  created() {
    if (!this.userId) {
      alert("User not found. Redirecting to login.");
      this.$router.push("/login");
      return;
    }
    this.fetchQuiz();
  },
  methods: {
    async fetchQuiz() {
      try {
        const response = await axios.get(`http://127.0.0.1:5000/quiz/${this.quizId}`);
        this.questions = response.data.quesList;
        this.timeDuration = this.convertTimeToSeconds(response.data.timeDuration);
        this.startTimer();
      } catch (error) {
        console.error("Error fetching quiz:", error);
      }
    },
    convertTimeToSeconds(timeString) {
      return timeString.split(":").reduce((acc, time) => 60 * acc + +time, 0);
    },
    startTimer() {
      this.timer = setInterval(() => {
        if (this.timeDuration > 0) {
          this.timeDuration--;
        } else {
          this.submitQuiz();
        }
      }, 1000);
    },
    saveAnswer() {
      if (this.selectedOption !== null) {
        const questionId = this.currentQuestion.id;
        const existingAnswerIndex = this.answers.findIndex((ans) => ans.questionId === questionId);

        if (existingAnswerIndex !== -1) {
          this.answers[existingAnswerIndex].selectedOption = this.selectedOption;
        } else {
          this.answers.push({ questionId, selectedOption: this.selectedOption });
        }
      }
    },
    saveAnswerAndNext() {
      this.saveAnswer();

      if (this.currentIndex < this.questions.length - 1) {
        this.currentIndex++;
        this.selectedOption = null;
      }
    },
    async submitQuiz() {
      if (!confirm("Are you sure you want to submit the quiz?")) return;

      this.saveAnswer(); // Ensure last answer is stored before submitting
      clearInterval(this.timer);

      console.log("Submitting answers:", this.answers); // Debugging log
      console.log("User ID:", this.userId);
      console.log("Quiz ID:", this.quizId);

      try {
        const response = await axios.post("http://127.0.0.1:5000/quiz/submit", {
          userId: this.userId,
          quizId: this.quizId,
          answers: this.answers,
        });

        console.log("Response:", response.data);

        if (response.status === 200) {
          alert("Quiz submitted successfully!");

          console.log(`Redirecting to: /user/dashboard/${this.userId}`);

          // Attempt normal Vue Router redirection
          try {
            this.$router.push(`/user/dashboard/${this.userId}`);
          } catch (routerError) {
            console.error("Vue Router error:", routerError);
            console.log("Forcing redirect...");
            window.location.href = `http://localhost:8080/user/dashboard/${this.userId}`;
          }
        } else {
          console.error("Unexpected response:", response);
        }
      } catch (error) {
        console.error("Error submitting quiz:", error.response ? error.response.data : error.message);
      }
    },
  },
};
</script>

<style scoped>
.quiz-container {
  max-width: 600px;
  margin: auto;
}
.timer-box {
  background: #007bff;
  color: white;
  padding: 8px 15px;
  border-radius: 5px;
  font-size: 18px;
  font-weight: bold;
}
</style>
