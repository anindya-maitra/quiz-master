<template>
  <div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom shadow-sm p-1">
      <div class="container-fluid">
        <!-- <a class="navbar-brand fw-bold" href="#">Dashboard</a> -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item"><router-link to="#" class="nav-link">Home</router-link></li>
            <li class="nav-item">
              <router-link v-if="computedUserId" :to="`/user/scores/${computedUserId}`" class="nav-link">Scores</router-link>
            </li>
            <li class="nav-item"><router-link :to="`/user/summary/${loggedInUserId}`" class="nav-link">View Summary</router-link></li>
            <li class="nav-item"><router-link to="/" class="nav-link">Logout</router-link></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Performance Summary -->
    <div class="container mt-4">
      <div class="row">
        <div class="col-md-4" v-for="(value, key) in stats" :key="key">
          <div class="card stat-card">
            <div class="card-body text-center">
              <h5 class="card-title">{{ formatStatTitle(key) }}</h5>
              <p class="card-text display-4">{{ value }}</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Quiz Scores Table -->
      <h3 class="mt-5">Quiz Scores</h3>
      <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead class="table-primary">
            <tr>
              <th>ID</th>
              <th>Subject</th>
              <th>Chapter</th>
              <th>#Questions</th>
              <th>Question Title</th>
              <th>Date</th>
              <th>Score</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(quiz, index) in quizScores" :key="quiz.id">
              <td>{{ index + 1 }}</td>
              <td>{{ quiz.subject }}</td>
              <td>{{ quiz.chapter }}</td>
              <td>{{ quiz.numQuestions }}</td>
              <td>{{ quiz.questionTitle }}</td>
              <td>{{ quiz.date }}</td>
              <td>{{ quiz.score.toFixed(2) }}%</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "UserScores",
  props: ["userId"],
  data() {
    return {
      userName: "",
      stats: { totalQuizzes: 0, highestScore: 0, averageScore: 0 },
      quizScores: [],
    };
  },
  computed: {
    computedUserId() {
      return this.userId || JSON.parse(localStorage.getItem("user"))?.id || null;
    },
  },
  created() {
    if (!this.computedUserId) {
      this.$router.push("/login");
      return;
    }

    this.userName = JSON.parse(localStorage.getItem("user"))?.fullName || "User";

    if (this.$route.params.userId !== String(this.computedUserId)) {
      alert("Unauthorized access!");
      this.$router.push("/login");
      return;
    }

    this.fetchScores();
  },
  methods: {
    async fetchScores() {
      try {
        const response = await axios.get(`http://127.0.0.1:5000/user/scores/${this.computedUserId}`);
        const data = response.data;
        this.stats = {
          totalQuizzes: data.quizAttempted,
          highestScore: parseFloat(data.maxScored).toFixed(2),
          averageScore: parseFloat(data.avgScored).toFixed(2),
        };
        this.quizScores = data.quizScores;
      } catch (error) {
        console.error("Error fetching scores:", error);
      }
    },
    formatStatTitle(key) {
      const titles = {
        totalQuizzes: "Total Quizzes Attempted",
        highestScore: "Highest Score % (till now)",
        averageScore: "Average Score % (till now)",
      };
      return titles[key] || key;
    },
  },
};
</script>

<style scoped>
/* Navbar */
.navbar {
  background-color: #b2d5f8 !important;
  border-bottom: 2px solid #ccc;
}
.navbar-nav .nav-link {
  color: black;
  font-weight: 500;
}

/* Performance Summary */
.stat-card {
  background: #f8f9fa;
  border-left: 5px solid #007bff;
  padding: 10px;
  text-align: center;
}

/* Table */
.table {
  margin-top: 20px;
}
.table th,
.table td {
  text-align: center;
  vertical-align: middle;
}
</style>
