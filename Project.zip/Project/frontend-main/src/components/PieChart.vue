<template>
  <div>
    <canvas ref="pieChart"></canvas>
  </div>
</template>

<script>
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

export default {
  props: ["chartData"],
  data() {
    return {
      chartInstance: null,
    };
  },
  watch: {
    chartData: {
      deep: true,
      handler(newData) {
        if (this.chartInstance) {
          this.chartInstance.destroy();
        }
        this.renderChart(newData);
      },
    },
  },
  mounted() {
    if (this.chartData && this.chartData.labels.length > 0) {
      this.renderChart(this.chartData);
    }
  },
  methods: {
    renderChart(data) {
      if (!this.$refs.pieChart) return;

      this.chartInstance = new Chart(this.$refs.pieChart, {
        type: "pie",
        data,
        options: { responsive: true, maintainAspectRatio: false },
      });
    },
  },
  beforeUnmount() {
    if (this.chartInstance) {
      this.chartInstance.destroy();
    }
  },
};
</script>
