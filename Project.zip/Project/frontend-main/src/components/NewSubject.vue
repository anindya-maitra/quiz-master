<template>
    <div class="container mt-4">
      <h2>Create a New Subject</h2>
      <form @submit.prevent="createSubject">
        <div class="form-group">
          <label for="subjectName">Subject Name</label>
          <input type="text" v-model="subject.name" class="form-control" id="subjectName" required>
        </div>
        <div class="form-group">
          <label for="subjectDesc">Description</label>
          <input type="text" v-model="subject.desc" class="form-control" id="subjectDesc" required>
        </div>
        <button type="submit" class="btn btn-primary me-2 mt-2">Add Subject</button>
        <router-link to="/admin/dashboard" class="btn btn-secondary mt-2">Back to Dashboard</router-link>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        subject: {
          name: "",
          desc: ""
        }
      };
    },
    methods: {
      createSubject() {
        fetch("http://localhost:5000/admin/subjects", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(this.subject),
        })
        .then(response => response.json())
        .then(() => {
          alert("Subject added successfully!");
          this.subject = { name: "", desc: "" };
        })
        .catch(error => console.error("Error:", error));
      }
    }
  };
  </script>


<style scoped>
  .navbar {
    background-color: #b2d5f8 !important;
    border-bottom: 2px solid #ccc;
  }
  .navbar-nav .nav-link {
    color: black;
    font-weight: 500;
  }
</style>