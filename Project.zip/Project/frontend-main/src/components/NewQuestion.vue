<template>
  <div class="container mt-4">
    <h3 class="text-dark fw-bold mt-3">Add New Question</h3>

    <form @submit.prevent="submitQuestion" class="p-3 border rounded shadow-sm bg-light">
      <!-- <div class="mb-3">
        <label class="fw-bold">Chapter ID:</label>
        <input type="text" v-model="question.chapter_id" class="form-control" required>
      </div> -->

      <div class="mb-3">
        <label class="fw-bold">Question Title:</label>
        <input type="text" v-model="question.q_title" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="fw-bold">Question Statement:</label>
        <textarea v-model="question.statement" class="form-control" rows="3" required></textarea>
      </div>

      <h5 class="text-success fw-bold mt-4">Single Option Correct</h5>

      <div class="mb-2">
        <label>Option 1:</label>
        <input type="text" v-model="question.option1" class="form-control" required>
      </div>
      <div class="mb-2">
        <label>Option 2:</label>
        <input type="text" v-model="question.option2" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="fw-bold">Correct Option:</label>
        <select v-model="question.correct_option" class="form-control w-25" required>
          <option value="1">Option 1</option>
          <option value="2">Option 2</option>
        </select>
      </div>

      <div class="d-flex justify-content-between">
        <button type="submit" class="btn btn-primary">Save</button>
        <router-link to="/admin/quizzes" class="btn btn-secondary">Close</router-link>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      question: { 
        chapter_id: "", 
        q_title: "", 
        statement: "", 
        option1: "", 
        option2: "", 
        correct_option: ""
      }
    };
  },
  computed: {
    quizId() {
      console.log("Quiz ID from route params:", this.$route.params.quizId); // Debugging
      return this.$route.params.quizId;
    }
  },
  mounted() {
    this.fetchQuizDetails();
  },
  methods: {
    fetchQuizDetails() {
      if (!this.quizId) {
        console.error("Quiz ID is missing in the route params!");
        return;
      }

      fetch(`http://localhost:5000/admin/quizzes/${this.quizId}`)
        .then(response => response.json())
        .then((responseData) => {
          if (responseData && responseData.chapter_id) {
            this.question.chapter_id = responseData.chapter_id;
          }
        })
        .catch((err) => console.error("Error fetching quiz details:", err));
    },
    
    submitQuestion() {
      console.log("Submitting question with quiz ID:", this.quizId); // Debugging

      if (!this.quizId) {
        alert("Quiz ID is missing! Please check the URL.");
        return;
      }

      const newQuestion = {
        quiz_id: this.quizId,  // Ensure quiz_id is included
        chapter_id: this.question.chapter_id, 
        question_statement: this.question.statement,
        option1: this.question.option1,
        option2: this.question.option2,
        correct_option: Number(this.question.correct_option), 
        q_title: this.question.q_title
      };

      console.log("Payload being sent:", JSON.stringify(newQuestion)); // Debugging

      fetch(`http://localhost:5000/admin/quizzes/questions/${this.quizId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newQuestion),
      })
        .then(response => response.json())
        .then(data => {
          console.log("Server Response:", data);
          alert("Question submitted successfully!");
          this.resetForm();
        })
        .catch(err => {
          console.error("Error submitting question:", err);
          alert("Failed to submit the question. Check the console for details.");
        });
    },

    resetForm() {
      this.question = { 
        chapter_id: this.question.chapter_id, 
        q_title: "", 
        statement: "", 
        option1: "", 
        option2: "", 
        correct_option: "1" 
      };
    }
  }
};
</script>
