<template>
  <div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom shadow-sm p-1">
      <div class="container-fluid">
        <div class="collapse navbar-collapse">
          <ul class="navbar-nav me-auto">
            <li class="nav-item"><router-link to="/admin/dashboard" class="nav-link">Home</router-link></li>
            <li class="nav-item"><router-link to="/admin/quizzes" class="nav-link">Quizzes</router-link></li>
            <li class="nav-item"><router-link to="/admin/summary" class="nav-link">Summary</router-link></li>
            <li class="nav-item"><router-link to="/" class="nav-link">Logout</router-link></li>
          </ul>
          <span class="fw-bold text-dark">Welcome, Admin!</span>
        </div>
      </div>
    </nav>

    <!-- Summary Charts -->
    <div class="container mt-4">
      <h3 class="text-center">Admin Summary Charts</h3>
      <div class="row">
        <div class="col-md-6">
          <h5 class="text-center">Subject-wise Top Scores (%)</h5>
          <BarChart :chartData="topScoresChartData" :chartOptions="topScoresChartOptions" :key="topScoresChartKey" />
        </div>
        <div class="col-md-6">
          <h5 class="text-center">Subject-wise User Attempts</h5>
          <PieChart :chartData="userAttemptsChartData" :key="userAttemptsChartKey" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import BarChart from "@/components/BarChart.vue";
import PieChart from "@/components/PieChart.vue";

export default {
  name: "AdminCharts",
  components: { BarChart, PieChart },
  data() {
    return {
      topScoresChartData: { labels: [], datasets: [{ data: [] }] },
      userAttemptsChartData: { labels: [], datasets: [{ data: [] }] },
      topScoresChartKey: 0,
      userAttemptsChartKey: 0,

      // Chart options to hide legend
      topScoresChartOptions: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,  // 👈 This removes the legend
          },
        },
      },
    };
  },
  async created() {
    try {
      const response = await axios.get("http://127.0.0.1:5000/admin/summary");

      // Data extraction
      const subjects = Object.keys(response.data.top_scores);
      const scores = Object.values(response.data.top_scores);

      const attemptSubjects = Object.keys(response.data.user_attempts);
      const attempts = Object.values(response.data.user_attempts);

      // Chart data
      this.topScoresChartData = {
        labels: subjects,
        datasets: [
          {
            label: "Top Score",
            data: scores,
            backgroundColor: subjects.map((_, index) => [
              "#00FF00", "#00FFFF", "#FF0000", "#FFFF00", "#FF69B4",
              "#FFA500", "#800080", "#0000FF"
            ][index % 8]) 
          }
        ],
      };

      this.userAttemptsChartData = {
        labels: attemptSubjects,
        datasets: [
          {
            label: "User Attempts",
            data: attempts,
            backgroundColor: attemptSubjects.map((_, index) => [
              "#FF7675", "#55EFC4", "#FDCB6E", "#74B9FF", "#B4AEE8",
              "#D6A2E8", "#E67E22", "#16A085"
            ][index % 8])
          }
        ]
      };

      this.updateChartData();
    } catch (error) {
      console.error("Error fetching summary:", error);
    }
  },
  methods: {
    updateChartData() {
      this.topScoresChartKey++;
      this.userAttemptsChartKey++;
    }
  }
};
</script>

<style scoped>
.navbar {
  background-color: #b2d5f8 !important;
  border-bottom: 2px solid #ccc;
}
.navbar-nav .nav-link {
  color: black;
  font-weight: 500;
}
</style>
