<template>
  <div class="container mt-4">
    <h2>Manage Chapters</h2>
    <ul class="list-group">
      <li v-for="chapter in chapters" :key="chapter.id" class="list-group-item">
        {{ chapter.name }} - {{ chapter.desc }}
      </li>
    </ul>
    <form @submit.prevent="createChapter" class="mt-3">
      <div class="form-group">
        <input type="text" v-model="newChapter.name" class="form-control" placeholder="Chapter Name" required>
      </div>
      <div class="form-group">
        <input type="text" v-model="newChapter.desc" class="form-control" placeholder="Description" required>
      </div>
      <button type="submit" class="btn btn-primary mt-2">Add Chapter</button>
    </form>
  </div>
</template>

<script>
export default {
  name: "ChapterList",  
  data() {
    return {
      chapters: [],
      newChapter: { name: "", desc: "" },
    };
  },
  mounted() {
    fetch("http://localhost:5000/admin/chapters")
      .then((data) => (this.chapters = data));
  },
  methods: {
    createChapter() {
      fetch("http://localhost:5000/admin/chapters", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(this.newChapter),
      }).then(() => {
        this.chapters.push({ ...this.newChapter });
        this.newChapter = { name: "", desc: "" };
      });
    },
  },
};
</script>
