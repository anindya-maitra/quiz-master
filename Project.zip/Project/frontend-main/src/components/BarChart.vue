<template>
  <div>
    <canvas ref="barChart"></canvas>
  </div>
</template>

<script>
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

export default {
  props: ["chartData", "chartOptions"], // Accept `chartOptions` as a prop
  data() {
    return {
      chartInstance: null,
    };
  },
  watch: {
    chartData: {
      deep: true,
      handler(newData) {
        if (this.chartInstance) {
          this.chartInstance.destroy();
        }
        this.renderChart(newData, this.chartOptions); // Pass options
      },
    },
  },
  mounted() {
    if (this.chartData && this.chartData.labels.length > 0) {
      this.renderChart(this.chartData, this.chartOptions); // Pass options
    }
  },
  methods: {
    renderChart(data, options = {}) {
      if (!this.$refs.barChart) return;

      this.chartInstance = new Chart(this.$refs.barChart, {
        type: "bar",
        data,
        options,  // Use the passed options instead of hardcoded ones
      });
    },
  },
  beforeUnmount() {
    if (this.chartInstance) {
      this.chartInstance.destroy();
    }
  },
};
</script>
