<template>
    <div class="container mt-4">
      <h2>Create a New Chapter</h2>
      <form @submit.prevent="createChapter">
        <div class="form-group">
          <label for="chapterName">Chapter Name</label>
          <input type="text" v-model="chapter.name" class="form-control" id="chapterName" required>
        </div>
        <div class="form-group">
          <label for="chapterDesc">Description</label>
          <input type="text" v-model="chapter.desc" class="form-control" id="chapterDesc" required>
        </div>
        <div class="form-group">
          <label for="subjectSelect">Select Subject</label>
          <select v-model="chapter.subject_id" class="form-control" id="subjectSelect" required>
            <option v-for="subject in subjects" :key="subject.id" :value="subject.id">
              {{ subject.name }}
            </option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary mt-2 me-2">Add Chapter</button>
        <router-link to="/admin/dashboard" class="btn btn-secondary mt-2">Back to Dashboard</router-link>
      </form>
    </div>
  </template>
  
  <script>
    export default {
    data() {
        return {
        chapter: {
            name: "",
            desc: "",
            subject_id: null,
        },
        subjects: [],
        };
    },
    mounted() {
        this.fetchSubjects();
    },
    methods: {
        fetchSubjects() {
        fetch("http://localhost:5000/admin/subjects")
            .then((response) => response.json())
            .then((data) => {
            this.subjects = data;
            console.log("Fetched subjects:", this.subjects);
            })
            .catch((error) => console.error("Error fetching subjects:", error));
        },
        createChapter() {
        console.log("Creating chapter:", this.chapter);
        fetch("http://localhost:5000/admin/chapters", {
            method: "POST",
            headers: {
            "Content-Type": "application/json",
            },
            body: JSON.stringify(this.chapter),
        })
            .then((response) => response.json())
            .then(() => {
            this.$router.push("/admin/dashboard"); // Redirect after successful creation
            })
            .catch((error) => console.error("Error creating chapter:", error));
        },
    },
  };
</script>

<style scoped>
  .navbar {
    background-color: #b2d5f8 !important;
    border-bottom: 2px solid #ccc;
  }
  .navbar-nav .nav-link {
    color: black;
    font-weight: 500;
  }
</style>

  