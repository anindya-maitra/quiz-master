<template>
  <div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom shadow-sm p-1">
      <div class="container-fluid">
        <!-- Navbar Toggle Button -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item"><router-link to="/" class="nav-link">Home</router-link></li>
            <li class="nav-item"><router-link to="/user/scores" class="nav-link">Scores</router-link></li>
            <li class="nav-item"><router-link to="/user/summary" class="nav-link">Summary</router-link></li>
            <li class="nav-item"><router-link to="/" class="nav-link">Logout</router-link></li>
          </ul>
          <span class="fw-bold text-dark">Welcome, {{ userName }}!</span>
        </div>
      </div>
    </nav>

    <!-- Summary Charts -->
    <div class="container mt-4">
      <h3 class="text-center">Summary Charts</h3>
      <div class="row">
        <div class="col-md-6">
          <h5 class="text-center">Subject-wise Number of Quizzes</h5>
          <BarChart :chartData="subjectChartData" :chartOptions="subjectChartOptions" :key="subjectChartKey" />
        </div>
        <div class="col-md-6">
          <h5 class="text-center">Month-wise Number of Quizzes Attempted</h5>
          <PieChart :chartData="monthChartData" :key="monthChartKey" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import BarChart from "@/components/BarChart.vue";
import PieChart from "@/components/PieChart.vue";

export default {
  name: "UserSummary",
  components: { BarChart, PieChart },
  data() {
    return {
      userName: "User",
      subjectChartData: { labels: [], datasets: [{ data: [] }] },
      monthChartData: { labels: [], datasets: [{ data: [] }] },
      subjectChartKey: 0,
      monthChartKey: 0,

      // Chart options to hide legend
      subjectChartOptions: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false } // Removes legend from bar chart
        }
      }
    };
  },
  async created() {
    try {
      const storedUser = JSON.parse(localStorage.getItem("user"));
      const userId = storedUser?.id ?? null;
      this.userName = storedUser?.fullName || "User";

      if (!userId) {
        console.error("User ID not found! Redirecting to login...");
        this.$router.push("/login");
        return;
      }

      const response = await axios.get(`http://127.0.0.1:5000/user/summary/${userId}`);

      // Process subject data
      const subjects = Object.keys(response.data.subjectWise);
      const subjectCounts = Object.values(response.data.subjectWise);

      // Process month-wise quiz data with sorted months
      const monthOrder = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
      ];
      
      const sortedMonths = Object.keys(response.data.monthWise)
        .sort((a, b) => monthOrder.indexOf(a) - monthOrder.indexOf(b));

      const sortedMonthCounts = sortedMonths.map(m => response.data.monthWise[m]);

      this.subjectChartData = {
        labels: subjects,
        datasets: [
          {
            label: "Number of Quizzes",
            data: subjectCounts,
            backgroundColor: subjects.map((_, index) => [
              "#00FF00", "#00FFFF", "#FF0000", "#FFFF00", "#FF69B4",
              "#FFA500", "#800080", "#0000FF"
            ][index % 8]) // Assign colors dynamically
          }
        ]
      };

      this.monthChartData = {
        labels: sortedMonths,
        datasets: [
          {
            label: "Quizzes Attempted",
            data: sortedMonthCounts,
            backgroundColor: [
              "#FFFF00", "#FF69B4", "#FF0000", "#00FF00",
              "#0000FF", "#FFA500", "#800080", "#00FFFF"
            ]
          }
        ]
      };

      this.updateChartData();
    } catch (error) {
      console.error("Error fetching summary:", error);
    }
  },
  methods: {
    updateChartData() {
      this.subjectChartKey++;
      this.monthChartKey++;
    }
  }
};
</script>

<style scoped>
.navbar {
  background-color: #b2d5f8 !important;
  border-bottom: 2px solid #ccc;
}
.navbar-nav .nav-link {
  color: black;
  font-weight: 500;
}
</style>
