<template>
  <div>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom shadow-sm p-1">
      <div class="container-fluid">
        <!-- <a class="navbar-brand fw-bold" href="#">Dashboard</a> -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item"><router-link to="#" class="nav-link">Home</router-link></li>
            <li class="nav-item"><router-link :to="`/user/scores/${loggedInUserId}`" class="nav-link">Scores</router-link></li>
            <li class="nav-item"><router-link :to="`/user/summary/${loggedInUserId}`" class="nav-link">View Summary</router-link></li>
            <li class="nav-item"><router-link to="/" class="nav-link">Logout</router-link></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Dashboard Content -->
    <div class="container mt-4">
      <h2>Welcome, {{ userName }}!</h2>
      <p>Your recent quiz performance is shown below:</p>

      <!-- Available Quizzes Table -->
      <h3 class="mt-5">Available Quizzes</h3>
      <div class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead class="table-primary">
            <tr>
              <th>#</th>
              <th>Subject</th>
              <th>Chapter</th>
              <th>Difficulty</th>
              <th>Total Score</th>
              <th>Time Duration</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(quiz, index) in quizzes" :key="quiz.id">
              <td>{{ index + 1 }}</td>
              <td>{{ quiz.subjectName }}</td>
              <td>{{ quiz.chapterName }}</td>
              <td>{{ quiz.difficultyLevel }}</td>
              <td>{{ quiz.totalScore }}</td>
              <td>{{ quiz.timeDuration }}</td>
              <td>
                <button class="btn btn-info btn-sm me-2" @click="viewQuizDetails(quiz)">
                  {{ quiz.attempted ? "View Results" : "View Quiz" }}
                </button>
                <button v-if="!quiz.attempted" class="btn btn-success btn-sm" @click="startQuiz(quiz.id)">
                  Start Quiz
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Quiz Details Modal -->
    <div v-if="selectedQuiz" class="modal fade show d-block" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">{{ selectedQuiz.attempted ? "Quiz Results" : "Quiz Details" }}</h5>
            <button type="button" class="btn-close" @click="selectedQuiz = null"></button>
          </div>
          <div class="modal-body">
            <p><strong>Subject Name:</strong> {{ selectedQuiz.subjectName }}</p>
            <p><strong>Chapter Name:</strong> {{ selectedQuiz.chapterName }}</p>
            <p><strong>Difficulty Level:</strong> {{ selectedQuiz.difficultyLevel }}</p>
            <p><strong>Total Score:</strong> {{ selectedQuiz.totalScore }}</p>
            <p><strong>Time Duration:</strong> {{ selectedQuiz.timeDuration }}</p>

            <!-- Display the user's score if attempted -->
            <p v-if="selectedQuiz.attempted" class="text-success">
              <strong>Your Score:</strong> {{ selectedQuiz.userScore.toFixed(2) }}%
            </p>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" @click="selectedQuiz = null">Close</button>
            <button v-if="!selectedQuiz.attempted" class="btn btn-primary" @click="startQuiz(selectedQuiz.id)">
              Start Quiz
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Backdrop -->
    <div v-if="selectedQuiz" class="modal-backdrop fade show"></div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      userId: null,
      userName: "",
      loggedInUserId: "",
      stats: {
        totalQuizzes: 0,
        highestScore: 0,
        averageScore: 0,
      },
      quizzes: [],
      selectedQuiz: null, // Stores quiz details for modal
    };
  },
  created() {
    console.log("Route Params:", this.$route.params);
    console.log("LocalStorage User Data:", localStorage.getItem("user"));

    const userData = localStorage.getItem("user");
    if (userData) {
      const parsedUser = JSON.parse(userData);
      this.loggedInUserId = String(parsedUser.id); // Ensure it's a string
      this.userName = parsedUser.fullName;

      console.log("Extracted User ID:", this.loggedInUserId);

      // Ensure the route userId matches the logged-in user
      if (this.$route.params.userId !== this.loggedInUserId) {
        alert("Unauthorized access!");
        this.$router.push("/login");
      } else {
        this.fetchUserDashboard();
      }
    } else {
      this.$router.push("/login");
    }
  },
  methods: {
    async fetchUserDashboard() {
      try {
        console.log(`Fetching dashboard for user ID: ${this.loggedInUserId}`);
        
        const apiUrl = `http://127.0.0.1:5000/user/dashboard/${this.loggedInUserId}`;
        console.log("API URL:", apiUrl);

        const response = await axios.get(apiUrl);
        console.log("Dashboard API Response:", response.data);

        const data = response.data;
        this.stats = {
          totalQuizzes: data.quizAttempted,
          highestScore: data.maxScored,
          averageScore: data.avgScored,
        };

        // Grouping questions under each quiz
        const groupedQuizzes = data.quizList.reduce((acc, quiz) => {
          if (!acc[quiz.id]) {
            acc[quiz.id] = {
              id: quiz.id,
              subjectName: quiz.subjectName,
              chapterName: quiz.chapterName,
              difficultyLevel: quiz.difficultyLevel,
              totalScore: quiz.totalScore,
              timeDuration: quiz.timeDuration,
              attempted: quiz.attempted,
              userScore: quiz.userScore,
              questions: [],
            };
          }
          acc[quiz.id].questions.push(quiz.questionTitle);
          return acc;
        }, {});

        this.quizzes = Object.values(groupedQuizzes);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);

        if (error.response) {
          console.error("Response Data:", error.response.data);
          console.error("Status Code:", error.response.status);
        } else if (error.request) {
          console.error("No response received:", error.request);
        } else {
          console.error("Request error:", error.message);
        }
      }
    },
    startQuiz(quizId) {
      this.$router.push(`/quiz/${quizId}`);
    },
    viewQuizDetails(quiz) {
      this.selectedQuiz = quiz;
    },
    logout() {
      localStorage.removeItem("user");
      this.$router.push("/login");
    },
    formatStatTitle(key) {
      return key.replace(/([A-Z])/g, " $1").trim();
    },
  },
};
</script>

<style scoped>
/* Table Styling */
.table {
  margin-top: 20px;
}

.table th,
.table td {
  text-align: center;
  vertical-align: middle;
}

/* Dashboard Styling */
.stat-card {
  background: #f8f9fa;
  border-left: 5px solid #007bff;
  padding: 10px;
}

.navbar {
  background-color: #b2d5f8 !important;
  border-bottom: 2px solid #ccc;
}
.navbar-nav .nav-link {
  color: black;
  font-weight: 500;
}

/* Modal Backdrop */
.modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1040;
}

/* Modal Styling */
.modal {
  z-index: 1050;
}
</style>
