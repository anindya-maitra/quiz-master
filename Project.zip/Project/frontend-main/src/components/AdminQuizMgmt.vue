<template>
  <div class="container mt-4">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom shadow-sm p-2">
      <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">Quiz Management</a>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item"><router-link to="/admin/dashboard" class="nav-link">Home</router-link></li>
            <li class="nav-item"><router-link to="/admin/quizzes" class="nav-link">Quiz</router-link></li>
            <li class="nav-item"><router-link to="/admin/summary" class="nav-link">Summary</router-link></li>
            <li class="nav-item"><router-link to="/" class="nav-link">Logout</router-link></li>
          </ul>
          <div class="d-flex align-items-center w-50 ms-auto">
            <input type="text" v-model="searchQuery" @input="filterQuizzes" class="form-control me-2" placeholder="Search Quiz (Subject, Chapter, Difficulty level)">
          </div>
        </div>
      </div>
    </nav>

    <!-- <h4 class="navbar-text fw-bold mt-4 mb-3">Welcome, Admin!</h4> -->

    <!-- Quizzes Section -->
    <p class="mt-4 fw-bold text-secondary p-2">All quizzes here...</p>
    <div class="row">
      <div v-for="quiz in filteredQuizzes" :key="quiz.id" class="col-md-6 col-lg-5 card p-3 m-2">

        <h6 class="fw-bold text-secondary">Subject: {{ quiz.subject_name }}</h6>
        <div class="d-flex justify-content-between align-items-center">
          <h5 class="fw-bold m-0">Quiz on: {{ quiz.chapter_name }}</h5>
          <div class="ms-auto">
            <button @click="openEditQuizModal(quiz)" class="btn btn-sm btn-warning me-2">Edit Quiz</button>
            <button @click="confirmDeleteQuiz(quiz.id)" class="btn btn-sm btn-danger">Delete Quiz</button>
          </div>
        </div>

        <hr class="my-2">
        <p class="text-muted">Date created: {{ quiz.date_of_quiz }}</p>
        <p>Score: {{ quiz.total_score }} <br> Duration: {{ quiz.time_duration }} <br> Difficulty: {{ quiz.difficulty_level }}</p>

        <hr class="my-4">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Question Title</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(question, index) in quiz.questions" :key="question.id">
              <td>{{ index + 1 }}</td>
              <td>{{ question.q_title }}</td>
              <td>
                <button @click="openEditQuestionModal(question)" class="btn btn-sm btn-warning me-2">Edit</button>
                <button @click="confirmDeleteQuestion(question.id)" class="btn btn-sm btn-danger">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>

        <router-link :to="`/admin/new-question/${quiz.id}`" class="btn btn-success mt-3 mb-3">
            + Add Question
        </router-link>
      </div>
    </div>


    <div class="text-center">
      <router-link to="/admin/new-quiz" class="btn btn-success mt-3 mb-3">+ Add New Quiz</router-link>
    </div>


    <!-- Edit Quiz Modal -->
    <div v-if="showEditQuizModal" class="modal d-block">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Quiz</h5>
            <button type="button" class="btn-close" @click="closeEditQuizModal"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="updateQuiz">
              <div class="mb-3">
                <label class="form-label">Date of Quiz</label>
                <input type="date" class="form-control" v-model="selectedQuiz.date_of_quiz">
              </div>
              <div class="mb-3">
                <label class="form-label">Total Score</label>
                <input type="number" class="form-control" v-model="selectedQuiz.total_score">
              </div>
              <div class="mb-3">
                <label class="form-label">Time Duration</label>
                <input type="time" class="form-control" v-model="selectedQuiz.time_duration">
              </div>
              <div class="mb-3">
                <label class="form-label">Difficulty Level</label>
                <select class="form-control" v-model="selectedQuiz.difficulty_level">
                  <option value="Easy">Easy</option>
                  <option value="Medium">Medium</option>
                  <option value="Hard">Hard</option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary">Update Quiz</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Question Modal -->
    <div v-if="showEditQuestionModal" class="modal d-block">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Question</h5>
            <button type="button" class="btn-close" @click="closeEditQuestionModal"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="updateQuestion">
              <div class="mb-3">
                <label class="form-label">Question Title</label>
                <input type="text" class="form-control" v-model="selectedQuestion.q_title">
              </div>
              <div class="mb-3">
                <label class="form-label">Question Statement</label>
                <input type="text" class="form-control" v-model="selectedQuestion.question_statement">
              </div>
              <div class="mb-3">
                <label class="form-label">Option 1</label>
                <input type="text" class="form-control" v-model="selectedQuestion.option1">
              </div>
              <div class="mb-3">
                <label class="form-label">Option 2</label>
                <input type="text" class="form-control" v-model="selectedQuestion.option2">
              </div>
              <div class="mb-3">
                <label class="fw-bold">Correct Option:</label>
                <select v-model="selectedQuestion.correct_option" class="form-control w-25" required>
                  <option value="1">{{ selectedQuestion.option1 }}</option>
                  <option value="2">{{ selectedQuestion.option2 }}</option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary">Update Question</button>
            </form>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      subjects: [],
      quizzes: [],
      filteredQuizzes: [],
      searchQuery: "",
      showEditQuizModal: false,
      showEditQuestionModal: false,
      selectedQuiz: {},
      selectedQuestion: {}
    };
  },
  mounted() {
    this.fetchQuizzes();
  },
  methods: {
    fetchSubjects() {
      fetch("http://localhost:5000/admin/subjects")
        .then(response => response.json())
        .then(data => {
          this.subjects = data.map(subject => ({
            ...subject,
            chapters: subject.chapters || [], // Ensure chapters array exists
          }));
        })
        .catch(error => console.error("Error fetching subjects:", error));
    },
    fetchQuizzes() {
      fetch("http://localhost:5000/admin/quizzes")
        .then(response => response.json())
        .then(data => {
          this.quizzes = data;
          this.filteredQuizzes = this.quizzes;
        })
        .catch(error => console.error("Error fetching quizzes:", error));
    },
    filterQuizzes() {
      const searchTerm = this.searchQuery ? this.searchQuery.toLowerCase() : "";

      this.filteredQuizzes = this.quizzes.filter(quiz => {
        const subjectName = quiz.subject_name ? quiz.subject_name.toLowerCase() : "";
        const chapterName = quiz.chapter_name ? quiz.chapter_name.toLowerCase() : "";
        const difficulty = quiz.difficulty_level ? quiz.difficulty_level.toLowerCase() : "";

        return (
          subjectName.includes(searchTerm) ||
          chapterName.includes(searchTerm) ||
          difficulty.includes(searchTerm)
        );
      });
    },
    openEditQuizModal(quiz) {
      this.selectedQuiz = { ...quiz };
      this.showEditQuizModal = true;
    },
    closeEditQuizModal() {
      this.showEditQuizModal = false;
    },
    async updateQuiz() {
      try {
        await fetch(`http://localhost:5000/admin/quizzes/${this.selectedQuiz.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chapter_id: this.selectedQuiz.chapter_id,
            date_of_quiz: this.selectedQuiz.date_of_quiz,
            total_score: this.selectedQuiz.total_score,
            time_duration: this.selectedQuiz.time_duration,
            difficulty_level: this.selectedQuiz.difficulty_level,
          }),
        });

        this.fetchQuizzes(); // Refresh quizzes after update
        this.closeEditQuizModal();
      } catch (error) {
        console.error("Error updating quiz:", error);
      }
    },
    openEditQuestionModal(question) {
      this.selectedQuestion = { ...question };
      this.showEditQuestionModal = true;
    },
    closeEditQuestionModal() {
      this.showEditQuestionModal = false;
    },
    updateQuestion() {
      fetch(`http://localhost:5000/admin/quizzes/questions/${this.selectedQuestion.id}`, {  // Corrected URL
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(this.selectedQuestion),
      })
        .then(response => response.json())
        .then(() => {
          this.fetchQuizzes();
          this.closeEditQuestionModal();
        })
        .catch(error => console.error("Error updating question:", error));
    },
    confirmDeleteQuestion(questionId) {
      if (confirm("Are you sure you want to delete this question?")) {
        fetch(`http://localhost:5000/admin/questions/${questionId}`, { method: "DELETE" })
          .then(response => {
            if (response.ok) {
              this.fetchQuizzes(); // Refresh quizzes after deletion
            } else {
              console.error('Error deleting question:', response);
            }
          })
          .catch(error => console.error('Error:', error));
      }
    }
  }
};
</script>
