<template>
  <div class="container mt-4">
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom shadow-sm p-1">
      <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">Admin Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item"><router-link to="/admin/dashboard" class="nav-link">Home</router-link></li>
            <li class="nav-item"><router-link to="/admin/quizzes" class="nav-link">Quiz</router-link></li>
            <li class="nav-item"><router-link to="/admin/summary" class="nav-link">Summary</router-link></li>
            <li class="nav-item"><router-link to="/" class="nav-link">Logout</router-link></li>
          </ul>
          
          <div class="d-flex align-items-center ms-auto">
            <input type="text" v-model="searchQuery" @input="filterResults" class="form-control me-2" placeholder="Search Subject or Chapter">
          </div>
        </div>
      </div>
    </nav>


    <h4 class="navbar-text text-primary fw-bold mt-4">Welcome, Admin!</h4>
    <!-- Subject Cards -->
    <p class="mt-4 text-left fw-bold text-secondary p-2">All subjects listed here...</p>
    <div class="row mt-4">
      <div v-for="subject in filteredSubjects" :key="subject.id" class="col-md-6">
        <div class="card mb-4">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0 flex-grow-1">
              <router-link :to="'/admin/subjects/' + subject.id" class="text-decoration-none text-dark">
                {{ subject.name }}
              </router-link>
            </h5>
            <div class="d-flex">
              <button class="btn btn-sm btn-warning me-2" @click="openEditModal(subject)">Edit Subject</button>
              <button class="btn btn-sm btn-danger" @click="confirmDeleteSubject(subject.id)">Delete Subject</button>
            </div>
          </div>
          <div class="card-body">
            <table class="table">
              <thead>
                <tr>
                  <th>Chapter Name</th>
                  <th>No. of Questions</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="chapter in subject.chapters" :key="chapter.id">
                  <td>{{ chapter.name }}</td>
                  <td>{{ chapter.questions }}</td>
                  <td>
                    <button class="btn btn-sm btn-warning me-2" @click="openEditChapterModal(chapter)">Edit</button>
                    <button class="btn btn-sm btn-danger" @click="confirmDeleteChapter(chapter.id)">Delete</button>
                  </td>
                </tr>
              </tbody>
            </table>
            <router-link to="/admin/new-chapter" class="btn btn-success mt-3">Add Chapter +</router-link>
          </div>
        </div>
      </div>
    </div>

    <!-- Add New Subject Button -->
    <div class="text-center mt-3">
      <router-link to="/admin/new-subject" class="btn btn-success mt-3">Add Subject +</router-link>
    </div>

    <!-- Edit Subject Modal -->
    <div class="modal fade" id="editSubjectModal" tabindex="-1" aria-labelledby="editSubjectModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editSubjectModalLabel">Edit Subject</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="updateSubject">
              <div class="form-group">
                <label for="editSubjectName">Subject Name</label>
                <input type="text" v-model="selectedSubject.name" class="form-control" id="editSubjectName" required>
              </div>
              <div class="form-group">
                <label for="editSubjectDesc">Description</label>
                <textarea v-model="selectedSubject.desc" class="form-control" id="editSubjectDesc" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary mt-2 me-2">Update Subject</button>
              <button type="button" class="btn btn-secondary mt-2" data-bs-dismiss="modal">Cancel</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Chapter Modal -->
    <div class="modal fade" id="editChapterModal" tabindex="-1" aria-labelledby="editChapterModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editChapterModalLabel">Edit Chapter</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="updateChapter">
              <div class="form-group">
                <label for="editChapterName">Chapter Name</label>
                <input type="text" v-model="selectedChapter.name" class="form-control" id="editChapterName" required>
              </div>
              <div class="form-group">
                <label for="editChapterDesc">Description</label>
                <textarea v-model="selectedChapter.desc" class="form-control" id="editChapterDesc" required></textarea>
              </div>
              <div class="form-group">
                <label for="editSubjectSelect">Select Subject</label>
                <select v-model="selectedChapter.subject_id" class="form-control" id="editSubjectSelect" required>
                  <option v-for="subject in subjects" :key="subject.id" :value="subject.id">
                    {{ subject.name }}
                  </option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary mt-2 me-2">Update Chapter</button>
              <button type="button" class="btn btn-secondary mt-2" data-bs-dismiss="modal">Cancel</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Modal } from "bootstrap";

export default {
  data() {
    return {
      subjects: [],
      filteredSubjects: [],
      searchQuery: "",
      selectedSubject: { id: null, name: "", desc: "" },
      selectedChapter: { id: null, name: "", desc: "", subject_id: null },
    };
  },
  mounted() {
    this.fetchSubjects();
  },
  methods: {
    fetchSubjects() {
      fetch("http://localhost:5000/admin/subjects")
        .then(response => response.json())
        .then(data => {
          this.subjects = data.map(subject => ({
            ...subject,
            chapters: subject.chapters || [],
          }));
          this.filteredSubjects = this.subjects;
        })
        .catch(error => console.error("Error fetching subjects:", error));
    },
    filterResults() {
      const query = this.searchQuery.toLowerCase();
      if (!query) {
        this.filteredSubjects = this.subjects; // Reset when empty
        return;
      }
      
      this.filteredSubjects = this.subjects.map(subject => {
        const filteredChapters = subject.chapters.filter(chapter => 
          chapter.name.toLowerCase().includes(query)
        );

        if (subject.name.toLowerCase().includes(query) || filteredChapters.length > 0) {
          return {
            ...subject,
            chapters: filteredChapters, // Show only matched chapters
          };
        }
        return null;
      }).filter(subject => subject !== null); // Remove unmatched subjects
    },
    // Open Edit Modal with subject details
    openEditModal(subject) {
      if (!subject) return;
      this.selectedSubject = { ...subject }; // Copy subject object

      this.$nextTick(() => {  // Ensures DOM updates before accessing modal
        const modalElement = document.getElementById("editSubjectModal");
        if (modalElement) {
          const modalInstance = new Modal(modalElement);
          modalInstance.show();
        }
      });
    },

    // Update Subject
    updateSubject() {
      fetch(`http://localhost:5000/admin/subjects/${this.selectedSubject.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(this.selectedSubject),
      })
        .then((response) => {
          if (!response.ok) throw new Error("Failed to update subject");
          return response.json();
        })
        .then(() => {
          this.fetchSubjects();
          const modalElement = document.getElementById("editSubjectModal");
          const modalInstance = Modal.getInstance(modalElement);
          modalInstance.hide();
        })
        .catch((error) => console.error("Error updating subject:", error));
    },

    // Confirm before deleting a subject
    confirmDeleteSubject(subjectId) {
      if (confirm("Are you sure you want to delete this subject?")) {
        this.deleteSubject(subjectId);
      }
    },

    // Delete subject
    deleteSubject(subjectId) {
      fetch(`http://localhost:5000/admin/subjects/${subjectId}`, { method: "DELETE" })
        .then(response => response.json())
        .then(data => {
          if (data.error) {
            alert(data.error); // Prevent deleting subjects with chapters
          } else {
            this.subjects = this.subjects.filter(subject => subject.id !== subjectId);
          }
        })
        .catch(error => console.error("Error deleting subject:", error));
    },
    openEditChapterModal(chapter) {
      fetch(`http://localhost:5000/admin/chapters/${chapter.id}`)
        .then(response => response.json())
        .then(data => {
          console.log("Fetched Chapter Data:", data); // Debugging
          this.selectedChapter = data;  // Store fetched chapter details

          // Open Bootstrap modal
          const modalElement = document.getElementById("editChapterModal");
          const modalInstance = new Modal(modalElement);
          modalInstance.show();
        })
        .catch(error => console.error("Error fetching chapter:", error));
    },
    updateChapter() {
      fetch(`http://localhost:5000/admin/chapters/${this.selectedChapter.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(this.selectedChapter),
      })
        .then((response) => {
          if (!response.ok) throw new Error("Failed to update chapter");
          return response.json();
        })
        .then(() => {
          this.fetchSubjects();
          const modalElement = document.getElementById("editChapterModal");
          const modalInstance = Modal.getInstance(modalElement);
          modalInstance.hide();
        })
        .catch((error) => console.error("Error updating chapter:", error));
    },
    confirmDeleteChapter(chapterId) {
      if (confirm("Are you sure you want to delete this chapter?")) {
        this.deleteChapter(chapterId);
      }
    },
    deleteChapter(chapterId) {
      fetch(`http://localhost:5000/admin/chapters/${chapterId}`, { method: "DELETE" })
        .then(() => {
          this.subjects = this.subjects.map(subject => ({
            ...subject,
            chapters: subject.chapters.filter(chapter => chapter.id !== chapterId),
          }));
          
          this.fetchSubjects();
        })
        .catch(error => console.error("Error deleting chapter:", error));
    },
  },
};
</script>

<style scoped>
.navbar {
  background-color: #b2d5f8 !important;
  border-bottom: 2px solid #ccc;
}
.navbar-nav .nav-link {
  color: black;
  font-weight: 500;
}
</style>
