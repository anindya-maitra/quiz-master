1) Unzip the whole project folder and navigate to the folder from where both folders - backend and frontend-main can be seen together. Do nmp install to download all node-modules.

2) Open a terminal and run these commands:
    cd backend
    python app.py

3) Open another terminal and run these commands:
    cd frontend-main
    npx vue-cli-service serve
    Click on the local host link that will be shown

4) To get the DB details, I have used 2 things:
    - sqlite viewer - available online on internet
    - From main project folder where backend and frontend-main are there -> cd backend -> sqlite3 instance/quizMasterDB.db - Run all required sqlite commands to manipulate the DB instance, if required