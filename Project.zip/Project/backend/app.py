from flask import Flask
from app import createApp
from flask_cors import CORS
from flask_caching import Cache
from flask_compress import Compress



app = createApp()
CORS(app)

app.config['CACHE_TYPE'] = 'RedisCache'
app.config['CACHE_DEFAULT_TIMEOUT'] = 600  # Default TTL (10 minutes)
app.config['CACHE_REDIS_URL'] = "redis://localhost:6379/0"

cache = Cache(app)
Compress(app)

if __name__ == "__main__":
    app.run(debug=True)