import sqlite3

def setupDatabase():
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        # USER table
        con.execute('''
            CREATE TABLE IF NOT EXISTS user (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                full_name TEXT NOT NULL,
                qualification TEXT NOT NULL,
                dob DATE,
                is_admin BOOLEAN DEFAULT FALSE     
            )
        ''')

        # ADMIN account creation
        cursor = con.cursor()
        cursor.execute(
            '''SELECT * FROM user WHERE email = "quizmaster@goquizing.com"'''
        )
        admin = cursor.fetchone()
        if not admin:
            con.execute('''
                INSERT INTO user ("email", "password", "full_name", "qualification", "dob", "is_admin")
                VALUES("quizmaster@goquizing.com", "admin123", "Quiz Master", "Quiz Master Pro", '2001-07-10', 1)
            ''')

        # SUBJECT table
        con.execute('''
            CREATE TABLE IF NOT EXISTS subject (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                desc TEXT NOT NULL    
            )
        ''')

        # CHAPTER table (Fixed missing subject_id)
        con.execute('''
            CREATE TABLE IF NOT EXISTS chapter (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                desc TEXT NOT NULL,
                subject_id INTEGER NOT NULL,
                FOREIGN KEY(subject_id) REFERENCES subject(id) ON DELETE CASCADE
            )
        ''')

        # QUIZ table
        con.execute('''
            CREATE TABLE IF NOT EXISTS quiz (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chapter_id INTEGER NOT NULL,
                date_of_quiz DATETIME DEFAULT CURRENT_TIMESTAMP,
                total_score INTEGER NOT NULL,
                time_duration TIME NOT NULL,
                difficulty_level TEXT NOT NULL,
                FOREIGN KEY(chapter_id) REFERENCES chapter(id) ON DELETE CASCADE
            )
        ''')

        con.execute('''
            CREATE TABLE IF NOT EXISTS question (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quiz_id INTEGER NOT NULL,
                question_statement TEXT NOT NULL,
                option1 TEXT NOT NULL,
                option2 TEXT NOT NULL,
                correct_option INTEGER NOT NULL CHECK(correct_option IN (1, 2)),
                q_title TEXT NOT NULL,
                FOREIGN KEY (quiz_id) REFERENCES quiz(id) ON DELETE CASCADE
            )

        ''')

        # SCORE table (Added ON DELETE CASCADE for proper referencing)
        con.execute('''
            CREATE TABLE IF NOT EXISTS score (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quiz_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                timestamp_of_attempt DATETIME DEFAULT CURRENT_TIMESTAMP,
                total_scored INTEGER NOT NULL,
                FOREIGN KEY(quiz_id) REFERENCES quiz(id) ON DELETE CASCADE,
                FOREIGN KEY(user_id) REFERENCES user(id) ON DELETE CASCADE
            )
        ''')

        con.commit()

# User login function
def userLogin(email, password):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute(
            '''SELECT * FROM user WHERE email = ? AND password = ? ''', (email, password)
        )
    return cursor.fetchone()

# Insert new user function
def insertUser(user):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute(
            '''INSERT INTO user ("email", "password", "full_name", "qualification", "dob") VALUES (?, ?, ?, ?, ?)''',
            (user['email'], user['password'], user['fullName'], user['qualification'], user['dob'])
        )
    con.commit()

# Get user by ID
def getUserById(userId):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute(
            '''SELECT * FROM user WHERE id = ? ''', (userId,)
        )
    return cursor.fetchone()

# Get all quizzes
def getQuiz():
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute(
            '''SELECT * FROM quiz '''
        )
    return cursor.fetchall()
