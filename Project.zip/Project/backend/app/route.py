from flask import Blueprint, jsonify, request
from .database import *


main = Blueprint('main', __name__)

@main.before_app_request
def setup():
    setupDatabase()

@main.route("/", methods=['GET'])
def home():
    data = {
        "title": "Hello World, from Flask!" 
    }
    return jsonify(data)


# LOGIN
@main.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')

        conn = sqlite3.connect('instance/quizMasterDB.db')
        cursor = conn.cursor()

        cursor.execute("SELECT id, password, full_name, COALESCE(is_admin, 0) FROM user WHERE email = ?", (email,))
        user = cursor.fetchone()
        conn.close()

        if user:
            user_id, stored_password, full_name, is_admin = user

            if stored_password == password:
                return jsonify({
                    "status": "200",
                    "Message": "User Login Successful",
                    "user_id": user_id,
                    "full_name": full_name,
                    "is_admin": bool(is_admin),
                })

            return jsonify({"status": "403", "Message": "Incorrect password"}), 403

        return jsonify({"status": "403", "Message": "User not found"}), 403

    except Exception as e:
        print("Error:", str(e))
        return jsonify({"status": "500", "Message": "Internal Server Error"}), 500


# SIGNUP
@main.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        data = request.get_json()
        user = {}
        user['email'] = data.get('email')
        user['password'] = data.get('password')
        user['fullName'] = data.get('fullName')
        user['qualification'] = data.get('qualification')
        user['dob'] = data.get('dob')

        confirmPassword = data.get('confirmPassword')

        if user['password'] != confirmPassword:
            data = {
                "status": "400",
                "Message": "Both the passwords should match!"
            }
            return jsonify(data)
        
        try:
            insertUser(user)
            data = {
                "status": "201",
                "Message": "Account is successfully created. Please login to continue."
            }
            return jsonify(data)
        except sqlite3.IntegrityError:
            data = {
                "status": "400",
                "Message": "The email is already in use!"
            }
            return jsonify(data)
        
        
        
        
                
        
# ------------------- USER DASHBOARD -------------------
@main.route('/user/dashboard/<int:userId>', methods=['GET'])
def userDashboard(userId):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()

        # Fetch user details
        cursor.execute('SELECT full_name FROM user WHERE id = ?', (userId,))
        user = cursor.fetchone()
        userName = user[0] if user else "User"

        # Get user quiz stats
        cursor.execute('SELECT COUNT(*) FROM score WHERE user_id = ?', (userId,))
        quizAttempted = cursor.fetchone()[0]

        cursor.execute('SELECT MAX(total_scored) FROM score WHERE user_id = ?', (userId,))
        maxScored = cursor.fetchone()[0] or 0

        cursor.execute('SELECT AVG(total_scored) FROM score WHERE user_id = ?', (userId,))
        avgScored = round(cursor.fetchone()[0] or 0.00, 2)

        # Fetch quizzes along with subject name, chapter name, and question title
        cursor.execute('''
            SELECT q.id, c.name AS chapter_name, s.name AS subject_name, ques.q_title, 
                q.date_of_quiz, q.total_score, q.time_duration, q.difficulty_level
            FROM quiz q
            JOIN chapter c ON q.chapter_id = c.id
            JOIN subject s ON c.subject_id = s.id
            LEFT JOIN question ques ON q.id = ques.quiz_id
        ''')
        quizzes = cursor.fetchall()

        quizList = []
        for quiz in quizzes:
            quiz_id = quiz[0]

            # Fetch the user's score if they attempted the quiz
            cursor.execute('SELECT total_scored FROM score WHERE user_id = ? AND quiz_id = ?', (userId, quiz_id))
            score = cursor.fetchone()
            user_score = score[0] if score else None

            # Check if the user has attempted the quiz
            attempted = user_score is not None

            quizDict = {
                'id': quiz_id,
                'chapterName': quiz[1],
                'subjectName': quiz[2],
                'questionTitle': quiz[3] if quiz[3] else "No Title",  # Handle null case
                'dateOfQuiz': quiz[4],
                'totalScore': quiz[5],
                'timeDuration': quiz[6],
                'difficultyLevel': quiz[7],
                'attempted': attempted,
                'userScore': user_score
            }
            quizList.append(quizDict)

    data = {
        "userName": userName,
        "quizAttempted": quizAttempted,
        "maxScored": maxScored,
        "avgScored": avgScored,
        "quizList": quizList
    }
    return jsonify(data)


# QUIZ page for user
@main.route('/quiz/<int:quizId>', methods=['GET'])
def getQuiz(quizId):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        
        # Fetch only relevant questions
        cursor.execute('''SELECT id, question_statement, option1, option2 
                          FROM question 
                          WHERE quiz_id = ?''', (quizId,))
        queryResult = cursor.fetchall()
        
        quesList = []
        for ques in queryResult:
            quesList.append({
                'id': ques[0],
                'quesStatement': ques[1],
                'option1': ques[2],
                'option2': ques[3]
            })

        # Fetch time duration of quiz
        cursor.execute('''SELECT time_duration FROM quiz WHERE id = ?''', (quizId,))
        timeDuration = cursor.fetchone()
        
        if timeDuration:
            timeDuration = timeDuration[0]
        else:
            timeDuration = "00:00"  # Default if not found

    return jsonify({
        'timeDuration': timeDuration,
        'quesList': quesList
    })


# SUBMIT QUIZ
@main.route('/quiz/submit', methods=['POST'])
def submitQuiz():
    data = request.get_json()
    print(data)

    score = {}
    score['quizId'] = data.get('quizId')
    score['userId'] = data.get('userId')
    answers = data.get('answers')
    count = 0
    for answer in answers:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            cursor = con.cursor()
            cursor.execute(
                '''SELECT correct_option from question where id = ?''', (answer['questionId'],)
            )
            queryResult = list(cursor.fetchone())
            if answer['selectedOption'] == queryResult[0]:
                count += 1
    score['totalScored'] = (count / len(answers)) * 100
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute(
            '''INSERT INTO score (quiz_id, user_id, timestamp_of_attempt, total_scored) VALUES (?, ?, CURRENT_TIMESTAMP, ?)''', (score['quizId'], score['userId'], score['totalScored'])
        )
        con.commit()
    data = {
        'status': 201,
        'Message': 'Quiz score updated successfully'
    }

    return jsonify(data)



# User's score details page
@main.route('/user/scores/<int:userId>', methods=['GET'])
def userScores(userId):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()

        # Get user quiz stats
        cursor.execute('SELECT COUNT(*) FROM score WHERE user_id = ?', (userId,))
        quizAttempted = cursor.fetchone()[0] or 0

        cursor.execute('SELECT MAX(total_scored) FROM score WHERE user_id = ?', (userId,))
        maxScored = cursor.fetchone()[0] or 0

        cursor.execute('SELECT AVG(total_scored) FROM score WHERE user_id = ?', (userId,))
        avgScored = round(cursor.fetchone()[0] or 0.00, 2)

        # Fetch scores for only attempted quizzes
        cursor.execute('''
            SELECT q.id, COUNT(que.id), q.date_of_quiz, s.total_scored, 
                   sub.name AS subject_name, ch.name AS chapter_name, que.q_title
            FROM score s
            JOIN quiz q ON s.quiz_id = q.id
            JOIN chapter ch ON q.chapter_id = ch.id
            JOIN subject sub ON ch.subject_id = sub.id
            JOIN question que ON q.id = que.quiz_id
            WHERE s.user_id = ?
            GROUP BY q.id
            ORDER BY q.date_of_quiz DESC
        ''', (userId,))
        scores = cursor.fetchall()

        quizScores = [
            {
                'id': score[0],
                'numQuestions': score[1],
                'date': score[2],
                'score': score[3],
                'subject': score[4],
                'chapter': score[5],
                'questionTitle': score[6]
            }
            for score in scores
        ]

    data = {
        "quizAttempted": quizAttempted,
        "maxScored": maxScored,
        "avgScored": avgScored,
        "quizScores": quizScores
    }
    return jsonify(data)


# USER SUMMARY STATISTICS
@main.route('/user/summary/<int:userId>', methods=['GET'])
def user_summary(userId):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()

        # Subject-wise quiz count
        cursor.execute('''
            SELECT sub.name, COUNT(*)
            FROM score s
            JOIN quiz q ON s.quiz_id = q.id
            JOIN chapter ch ON q.chapter_id = ch.id
            JOIN subject sub ON ch.subject_id = sub.id
            WHERE s.user_id = ?
            GROUP BY sub.name
        ''', (userId,))
        subject_data = {row[0]: row[1] for row in cursor.fetchall()}

        # Month-wise quiz count (Converting month number to full month name)
        cursor.execute('''
            SELECT strftime('%m', s.timestamp_of_attempt) AS month_num, COUNT(*)
            FROM score s
            WHERE s.user_id = ?
            GROUP BY month_num
        ''', (userId,))
        
        month_map = {
            "01": "January", "02": "February", "03": "March", "04": "April",
            "05": "May", "06": "June", "07": "July", "08": "August",
            "09": "September", "10": "October", "11": "November", "12": "December"
        }
        
        month_data = {month_map[row[0]]: row[1] for row in cursor.fetchall() if row[0] in month_map}

        cursor.close()

    return jsonify({
        "subjectWise": subject_data or {}, 
        "monthWise": month_data or {}  
    })








# ------------------- ADMIN DASHBOARD -------------------
@main.route('/admin/dashboard', methods=['GET'])
def dashboard_summary():
    try:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            cursor = con.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM subject")
            subjects_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM quiz")
            quizzes_count = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM score")
            attempts_count = cursor.fetchone()[0]

        return jsonify({
            "total_subjects": subjects_count,
            "total_quizzes": quizzes_count,
            "total_attempts": attempts_count
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# SUBJECT ROUTES
@main.route('/admin/subjects', methods=['GET'])
def get_subjects():
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute("SELECT id, name, desc FROM subject")  # Including 'desc' field
        subjects = [{"id": row[0], "name": row[1], "desc": row[2], "chapters": []} for row in cursor.fetchall()]

        # Fetch chapters for each subject
        for subject in subjects:
            cursor.execute("SELECT id, name FROM chapter WHERE subject_id = ?", (subject["id"],))
            subject["chapters"] = [{"id": row[0], "name": row[1]} for row in cursor.fetchall()]

    return jsonify(subjects)


@main.route('/admin/subjects', methods=['POST'])
def create_subject():
    data = request.json
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute("INSERT INTO subject (name, desc) VALUES (?, ?)", (data['name'], data['desc']))
        con.commit()
    return jsonify({"message": "Subject created successfully"}), 201


@main.route('/admin/subjects/<int:subject_id>', methods=['GET'])
def get_subject(subject_id):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute("SELECT id, name, desc FROM subject WHERE id = ?", (subject_id,))
        subject = cursor.fetchone()

        if subject:
            subject_dict = {"id": subject[0], "name": subject[1], "desc": subject[2]}
            return jsonify(subject_dict), 200
        else:
            return jsonify({"error": "Subject not found"}), 404


@main.route('/admin/subjects/<int:subject_id>', methods=['PUT'])
def update_subject(subject_id):
    data = request.json
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute(
            "UPDATE subject SET name = ?, desc = ? WHERE id = ?",
            (data['name'], data['desc'], subject_id)
        )
        con.commit()
    return jsonify({"message": "Subject updated successfully"}), 200


@main.route('/admin/subjects/<int:subject_id>', methods=['DELETE'])
def delete_subject(subject_id):
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()

        # Check if subject has any associated chapters
        cursor.execute("SELECT COUNT(*) FROM chapter WHERE subject_id = ?", (subject_id,))
        chapter_count = cursor.fetchone()[0]

        if chapter_count > 0:
            return jsonify({"error": "Cannot delete subject with existing chapters"}), 400

        # Delete subject
        cursor.execute("DELETE FROM subject WHERE id = ?", (subject_id,))
        con.commit()

    return jsonify({"message": "Subject deleted successfully"}), 200





# CHAPTER ROUTES
@main.route('/admin/chapters', methods=['GET'])
def get_chapters():
    subject_id = request.args.get('subject_id')
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        con.row_factory = sqlite3.Row
        cursor = con.cursor()
        if subject_id:
            cursor.execute('SELECT id, name, desc, subject_id FROM chapter WHERE subject_id = ?', (subject_id,))
        else:
            cursor.execute('SELECT id, name, desc, subject_id FROM chapter')
        
        chapters = [dict(row) for row in cursor.fetchall()]

    return jsonify(chapters), 200

@main.route('/admin/chapters/<int:chapter_id>', methods=['GET'])
def get_chapter(chapter_id):
    try:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            con.row_factory = sqlite3.Row
            cursor = con.cursor()
            cursor.execute("SELECT id, name, desc, subject_id FROM chapter WHERE id = ?", (chapter_id,))
            chapter = cursor.fetchone()  # Fetch one chapter

        if chapter:
            return jsonify(dict(chapter)), 200  # Convert row to dictionary and return as JSON
        else:
            return jsonify({"error": "Chapter not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@main.route('/admin/chapters', methods=['POST'])
def create_chapter():
    data = request.json
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute('INSERT INTO chapter (name, desc, subject_id) VALUES (?, ?, ?)', 
                       (data['name'], data['desc'], data['subject_id']))
        con.commit()
    return jsonify({"message": "Chapter created successfully"}), 201


@main.route('/admin/chapters/<int:chapter_id>', methods=['PUT'])
def update_chapter(chapter_id):
    data = request.json
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()
        cursor.execute(
            'UPDATE chapter SET name = ?, desc = ?, subject_id = ? WHERE id = ?',
            (data['name'], data['desc'], data['subject_id'], chapter_id)
        )
        con.commit()
    return jsonify({"message": "Chapter updated successfully"}), 200

@main.route("/admin/chapters/<int:chapter_id>", methods=["DELETE"])
def delete_chapter(chapter_id):
    with sqlite3.connect('instance/quizMasterDB.db') as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM chapter WHERE id = ?", (chapter_id,))
        conn.commit()
        conn.close()
    return jsonify({"message": "Chapter deleted successfully"}), 200



# QUIZ ROUTES
@main.route('/admin/quizzes', methods=['GET'])
def get_quizzes():
    try:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            con.row_factory = sqlite3.Row
            cursor = con.cursor()
            cursor.execute("""
                SELECT q.id, q.chapter_id, q.date_of_quiz, q.total_score, q.time_duration, q.difficulty_level,
                        c.name AS chapter_name, s.name as subject_name,
                       qt.id AS question_id, qt.question_statement, qt.option1, qt.option2, qt.correct_option,
                       qt.q_title
                FROM quiz q
                LEFT JOIN question qt ON q.id = qt.quiz_id
                LEFT JOIN chapter c ON q.chapter_id = c.id
                LEFT JOIN subject s ON c.subject_id = s.id
            """)
            quizzes = {}
            for row in cursor.fetchall():
                quiz_id = row["id"]
                if quiz_id not in quizzes:
                    quizzes[quiz_id] = {
                        "id": row["id"],
                        "chapter_id": row["chapter_id"],
                        "chapter_name": row["chapter_name"],
                        "subject_name": row["subject_name"],
                        "date_of_quiz": row["date_of_quiz"],
                        "total_score": row["total_score"],
                        "time_duration": row["time_duration"],
                        "difficulty_level": row["difficulty_level"],
                        "questions": []
                    }
                if row["question_id"]:
                    quizzes[quiz_id]["questions"].append({
                        "id": row["question_id"],
                        "question_statement": row["question_statement"],
                        "option1": row["option1"],
                        "option2": row["option2"],
                        "correct_option": row["correct_option"],
                        "q_title": row["q_title"]
                    })
            return jsonify(list(quizzes.values())), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@main.route('/admin/quizzes', methods=['POST'])
def create_quiz():
    try:
        data = request.json
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            cursor = con.cursor()
            cursor.execute("""
                INSERT INTO quiz (chapter_id, date_of_quiz, total_score, time_duration, difficulty_level) 
                VALUES (?, ?, ?, ?, ?)
            """, (data['chapter_id'], data['date_of_quiz'], data['total_score'], data['time_duration'], data['difficulty_level']))
            con.commit()
        return jsonify({"message": "Quiz created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
    
@main.route('/admin/quizzes/<int:quiz_id>', methods=['GET'])
def get_quiz(quiz_id):
    try:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            con.row_factory = sqlite3.Row
            cursor = con.cursor()
            cursor.execute("""
                SELECT q.id, c.name AS chapter_name, q.total_score, q.time_duration, q.difficulty_level 
                FROM quiz q 
                JOIN chapter c ON q.chapter_id = c.id
                WHERE q.id = ?
            """, (quiz_id,))
            quiz = cursor.fetchone()
            if not quiz:
                return jsonify({"error": "Quiz not found"}), 404
            
            return jsonify({
                "id": quiz["id"],
                "chapter_name": quiz["chapter_name"],
                "total_score": quiz["total_score"],
                "time_duration": quiz["time_duration"],
                "difficulty_level": quiz["difficulty_level"]
            }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500



@main.route('/admin/quizzes/<int:quiz_id>', methods=['PUT'])
def edit_quiz(quiz_id):
    try:
        data = request.json
        
        # Ensure all required fields are present
        required_keys = ["chapter_id", "date_of_quiz", "total_score", "time_duration", "difficulty_level"]
        if not all(key in data for key in required_keys):
            return jsonify({"error": "Missing required fields"}), 400
        
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            cursor = con.cursor()
            cursor.execute("""
                UPDATE quiz
                SET chapter_id = ?, 
                    date_of_quiz = ?, 
                    total_score = ?, 
                    time_duration = ?, 
                    difficulty_level = ?
                WHERE id = ?
            """, (data['chapter_id'], data['date_of_quiz'], data['total_score'], data['time_duration'], data['difficulty_level'], quiz_id))
            con.commit()

            if cursor.rowcount == 0:
                return jsonify({"error": "Quiz not found"}), 404

        return jsonify({"message": "Quiz updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500



# Delete Quiz Route
@main.route('/admin/quizzes/<int:quiz_id>', methods=['DELETE'])
def delete_quiz(quiz_id):
    try:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            cursor = con.cursor()
            # Delete associated questions first to maintain referential integrity
            cursor.execute("DELETE FROM question WHERE quiz_id = ?", (quiz_id,))
            cursor.execute("DELETE FROM quiz WHERE id = ?", (quiz_id,))
            con.commit()
            if cursor.rowcount == 0:
                return jsonify({"error": "Quiz not found"}), 404
        return jsonify({"message": "Quiz deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    


# QUESTION ROUTES
@main.route('/admin/questions', methods=['GET'])
def get_questions():
    try:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            con.row_factory = sqlite3.Row
            cursor = con.cursor()
            cursor.execute("""
                SELECT id, quiz_id, chapter_id, question_statement, option1, option2, correct_option, q_title 
                FROM question
            """)
            questions = [dict(row) for row in cursor.fetchall()]
        return jsonify(questions), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
    
@main.route('/admin/quizzes/questions/<int:question_id>', methods=['GET'])
def get_question(question_id):
    try:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            con.row_factory = sqlite3.Row
            cursor = con.cursor()
            cursor.execute("""
                SELECT id, quiz_id, chapter_id, q_title, question_statement, option1, option2, correct_option
                FROM question WHERE id = ?
            """, (question_id,))
            question = cursor.fetchone()

        if question:
            return jsonify(dict(question)), 200
        else:
            return jsonify({"error": "Question not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@main.route('/admin/quizzes/questions/<int:quiz_id>', methods=['POST'])
def create_question(quiz_id):
    try:
        data = request.json
        required_fields = ['quiz_id','chapter_id', 'q_title', 'statement', 'option1', 'option2', 'correct_option']
        
        print(f"Received data: {data}")
        # if not all(field in data for field in required_fields):
        #     return jsonify({"error": "Missing required fields"}), 400

        with sqlite3.connect('instance/quizMasterDB.db') as con:
            cursor = con.cursor()
            cursor.execute("""
                INSERT INTO question (quiz_id, question_statement, option1, option2, correct_option, q_title)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (quiz_id, data['question_statement'], data['option1'], data['option2'], 
                  data['correct_option'], data['q_title']))
            con.commit()

        return jsonify({"message": "Question added successfully!"}), 201
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        return jsonify({"error": "An error occurred while inserting the question. Please try again."}), 500
    
    
@main.route('/admin/quizzes/questions/<int:question_id>', methods=['PUT'])
def update_question(question_id):
    try:
        data = request.json
        required_fields = ['q_title', 'question_statement', 'option1', 'option2', 'correct_option']

        # Ensure required fields are present
        if not all(field in data and data[field] is not None for field in required_fields):
            return jsonify({"error": "Missing required fields"}), 400

        with sqlite3.connect('instance/quizMasterDB.db') as con:
            cursor = con.cursor()

            # Check if the question exists
            cursor.execute("SELECT id FROM question WHERE id = ?", (question_id,))
            existing_question = cursor.fetchone()

            if not existing_question:
                return jsonify({"error": "Question not found"}), 404

            # Update question (without modifying chapter_id)
            cursor.execute("""
                UPDATE question
                SET q_title = ?, question_statement = ?, option1 = ?, option2 = ?, correct_option = ?
                WHERE id = ?
            """, (
                data['q_title'],
                data['question_statement'],  # Ensure this field exists
                data['option1'],
                data['option2'],
                data['correct_option'],
                question_id
            ))

            con.commit()

        return jsonify({"message": "Question updated successfully!"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@main.route('/admin/questions/<int:question_id>', methods=['DELETE'])
def delete_question(question_id):
    try:
        with sqlite3.connect('instance/quizMasterDB.db') as con:
            cursor = con.cursor()
            # Check if the question exists
            cursor.execute("SELECT * FROM question WHERE id = ?", (question_id,))
            question = cursor.fetchone()
            if not question:
                return jsonify({"error": "Question not found"}), 404

            cursor.execute("DELETE FROM question WHERE id = ?", (question_id,))
            con.commit()
        return jsonify({"message": "Question deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500





# ADMIN QUIZ STATISTICS
@main.route('/admin/summary', methods=['GET'])
def quiz_summary():
    with sqlite3.connect('instance/quizMasterDB.db') as con:
        cursor = con.cursor()

        # Fetch top scores for each subject
        cursor.execute("""
            SELECT sub.name, MAX(s.total_scored) as top_score
            FROM score s
            JOIN quiz q ON s.quiz_id = q.id
            JOIN chapter ch ON q.chapter_id = ch.id
            JOIN subject sub ON ch.subject_id = sub.id
            GROUP BY sub.name
        """)
        top_scores = {row[0]: row[1] for row in cursor.fetchall()}

        # Fetch user attempts per subject
        cursor.execute("""
            SELECT sub.name, COUNT(s.user_id) as attempts
            FROM score s
            JOIN quiz q ON s.quiz_id = q.id
            JOIN chapter ch ON q.chapter_id = ch.id
            JOIN subject sub ON ch.subject_id = sub.id
            GROUP BY sub.name
        """)
        user_attempts = {row[0]: row[1] for row in cursor.fetchall()}

    return jsonify({"top_scores": top_scores, "user_attempts": user_attempts})
