from app.route import send_email

# Sample test details
quiz_test_data = {
    "subject_name": "Mathematics",
    "chapter_name": "Algebra",
    "date_of_quiz": "2025-04-01",
    "difficulty_level": "Intermediate",
    "time_duration": 30,
    "total_score": 100
}

# Replace with your own email for testing
send_email("quizmaster.goquizing@gmail.com", quiz_test_data)
